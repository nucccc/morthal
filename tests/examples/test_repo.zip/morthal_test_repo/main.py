from lib import some_func

def hello_text() -> str:
	return 'hello world'

if __name__ == '__main__':
	print(hello_text())
	print()
	print(some_func())
