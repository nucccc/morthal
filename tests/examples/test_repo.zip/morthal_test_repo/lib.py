def some_func() -> str:
	result = 'maybe' + ' ' + 'some other day'
	return result

